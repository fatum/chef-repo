default[:statsd][:port] = 8125
default[:statsd][:graphite_port] = 2003
default[:statsd][:graphite_host] = "localhost"
